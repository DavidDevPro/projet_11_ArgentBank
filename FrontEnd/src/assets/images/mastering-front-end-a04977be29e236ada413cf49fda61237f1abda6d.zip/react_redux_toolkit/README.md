# Redux Toolkit

* Les étapes *

1 - npm i @reduxjs/toolkit react-redux
2 - Créer et configurer le store
3 - Créer slice (reducers)
4 - "useDispatch" pour lancer les reducers
5 - "useSelector" pour puiser la data dans le store
